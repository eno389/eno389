const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const path = require('path');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

const PORT = process.env.PORT || 3000;

// JSON verilerini işleme için body-parser kullan
app.use(bodyParser.json());

// MySQL bağlantısı oluştur
const db = mysql.createPool({
    host: '127.0.0.1',
    user: 'root', // MySQL kullanıcı adı
    password: '123qwe', // MySQL şifre
    database: 'chat_db' // Kullanılacak veritabanı adı
});

// MySQL bağlantısını test et
db.getConnection((err, connection) => {
    if (err) {
        console.error('MySQL bağlantı hatası: ', err);
        return;
    }
    console.log('MySQL bağlantısı başarılı!');
    connection.release();
});

// POST isteği ile mesaj gönderme
app.post('/send-message', (req, res) => {
    const { username, message } = req.body;
    const sql = 'INSERT INTO messages (username, message) VALUES (?, ?)';
    db.query(sql, [username, message], (err, result) => {
        if (err) {
            console.error('Mesaj ekleme hatası: ', err);
            res.status(500).json({ success: false, error: 'Mesaj ekleme hatası' });
            return;
        }
        res.json({ success: true });
        // Yeni mesajı tüm kullanıcılara gönder
        io.emit('newMessage', { username, message });
    });
});

// GET isteği ile tüm mesajları al
app.get('/messages', (req, res) => {
    const sql = 'SELECT * FROM messages ORDER BY timestamp DESC';
    db.query(sql, (err, results) => {
        if (err) {
            console.error('Mesajları getirme hatası: ', err);
            res.status(500).json({ success: false, error: 'Mesajları getirme hatası' });
            return;
        }
        res.json({ success: true, messages: results });
    });
});

// Public klasörünü statik dosyalar için kullan
app.use(express.static(path.join(__dirname, 'public')));

// Ana sayfa rota tanımlaması
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Socket.io kullanarak gerçek zamanlı iletişim sağlama
let messages = [];

io.on('connection', (socket) => {
    console.log('a user connected');
    
    // Sunucuya bağlandığında tüm mesajları gönder
    socket.emit('allMessages', messages);

    socket.on('disconnect', () => {
        console.log('user disconnected');
    });
});

server.listen(PORT, () => {
    console.log(`Sunucu ${PORT} portunda çalışıyor...`);
});
