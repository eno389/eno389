const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '12qw..',
    database: 'chat_db'
});

connection.connect((err) => {
    if (err) {
        console.error('Bağlantı hatası: ', err);
    } else {
        console.log('Bağlantı başarılı!');
    }
    connection.end();
});
