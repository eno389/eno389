document.getElementById('chat-form').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const message = document.getElementById('message').value;

    if (username && message) {
        fetch('/send-message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, message })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Başarılıysa mesajları yükle
                loadMessages();
                document.getElementById('message').value = ''; // Mesaj kutusunu temizle
            } else {
                console.error('Mesaj gönderilemedi');
            }
        })
        .catch(error => console.error('Hata:', error));
    }
});

function loadMessages() {
    fetch('/messages')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const messages = document.getElementById('messages');
                messages.innerHTML = ''; // Önceki mesajları temizle
                data.messages.forEach(msg => {
                    const newMessage = document.createElement('div');
                    newMessage.className = 'message';
                    newMessage.textContent = `${msg.username}: ${msg.message}`;
                    messages.appendChild(newMessage);
                });
            } else {
                console.error('Mesajlar yüklenemedi');
            }
        })
        .catch(error => console.error('Hata:', error));
}

// Sayfa yüklendiğinde ve her 5 saniyede bir mesajları yükle
window.onload = function() {
    loadMessages(); // Sayfa ilk yüklendiğinde mesajları yükle

    // Her 5 saniyede bir mesajları güncelle
    setInterval(function() {
        loadMessages();
    }, 5000); // 5000 milisaniye = 5 saniye
};

// Socket.io ile gerçek zamanlı iletişim
const socket = io();

socket.on('allMessages', (messages) => {
    // Tüm mevcut mesajları al
    messages.forEach(message => {
        const newMessage = document.createElement('div');
        newMessage.className = 'message';
        newMessage.textContent = `${message.username}: ${message.message}`;
        document.getElementById('messages').appendChild(newMessage);
    });
});

socket.on('newMessage', (message) => {
    // Yeni mesajı ekrana ekle
    const newMessage = document.createElement('div');
    newMessage.className = 'message';
    newMessage.textContent = `${message.username}: ${message.message}`;
    document.getElementById('messages').appendChild(newMessage);
});
